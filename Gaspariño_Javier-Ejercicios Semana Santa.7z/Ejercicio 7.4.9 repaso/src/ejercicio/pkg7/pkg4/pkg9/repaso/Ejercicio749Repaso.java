/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7.pkg4.pkg9.repaso;

import java.util.Scanner;

/**
 *
 * @author MM ISLAZUL
 */
public class Ejercicio749Repaso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int numeros[] = new int[8];

        System.out.println("Introduzca el primer numero:");
        numeros[0] = sc.nextInt();

        System.out.println("Introduzca el segundo numero:");
        numeros[1] = sc.nextInt();

        System.out.println("Introduzca el tercer numero:");
        numeros[2] = sc.nextInt();

        System.out.println("Introduzca el cuarto numero:");
        numeros[3] = sc.nextInt();

        System.out.println("Introduzca el quinto numero:");
        numeros[4] = sc.nextInt();

        System.out.println("Introduzca el sexto numero:");
        numeros[5] = sc.nextInt();

        System.out.println("Introduzca el septimo numero");
        numeros[6] = sc.nextInt();

        System.out.println("Introduzca el octavo numero");
        numeros[7] = sc.nextInt();

        for (int i = 0; i < 8; i++) {
            if (numeros[i] % 2 == 0) {
                System.out.println("\nEl numero " + numeros[i] + " es par");
            } else {
                System.out.println("\nEl numero " + numeros[i] + " es impar");
            }
        }
    }

}
