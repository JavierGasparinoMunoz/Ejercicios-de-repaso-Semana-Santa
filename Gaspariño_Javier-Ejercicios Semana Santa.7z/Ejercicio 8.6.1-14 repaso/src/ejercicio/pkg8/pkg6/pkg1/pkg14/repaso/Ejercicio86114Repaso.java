/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg8.pkg6.pkg1.pkg14.repaso;

import java.util.Scanner;

/**
 *
 * @author MM ISLAZUL
 */
public class Ejercicio86114Repaso {

    /**
     * @param args the command line arguments
     */
    public static void esCapicua() {
        Scanner sc = new Scanner(System.in);
        String numero;
        boolean es = true;

        System.out.println("Introduce un numero");
        numero = sc.nextLine();

        char[] chararray = numero.toCharArray();
        int[] numeros = new int[chararray.length];

        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = chararray[i] - 48;
        }

        for (int i = 0; i < (numeros.length / 2); i++) {
            if (numeros[i] != numeros[numeros.length - i - 1]) {

                es = false;
                break;
            }
        }
        if (es == false) {
            System.out.println("Falso");
        } else {
            System.out.println("Verdadero");
        }
    }
    
     public static void esPrimo(){
     Scanner sc = new Scanner(System.in);
     int numero;
     
     System.out.println("Introduce un numero");
     numero = sc.nextInt();
     
     if (numero % 2 != 0){
         System.out.println("Verdadero");
     } else if(numero == 2){
     System.out.println("Verdadero");
     } else {
         System.out.println("Falso");
     }

     }

     public static void digitos(){
     Scanner sc = new Scanner(System.in);
     int numero;
     int longitud = 0;
     String numeros;
     
     System.out.println("Introduce un numero");
     numero = sc.nextInt();
     
     numeros = Integer.toString(numero);
     
     longitud = numeros.length();
     
     System.out.println("\nTiene " + longitud + " digitos");
     }
             
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String eleccion;
        
        System.out.println("¿Que funcion quieres ejecutar?");
        eleccion = sc.nextLine().toLowerCase();
        
        switch (eleccion){
            case "capicua":
                System.out.println("");
                esCapicua();
                break;
            case "primo":
                System.out.println("");
                esPrimo();
                break;
            case "digitos":
                System.out.println("");
                digitos();
                break;    
                
        }
        
        

    }
}
