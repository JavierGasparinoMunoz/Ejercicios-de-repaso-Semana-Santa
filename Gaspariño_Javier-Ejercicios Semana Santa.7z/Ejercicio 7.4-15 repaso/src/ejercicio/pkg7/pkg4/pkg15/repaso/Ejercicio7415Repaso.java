/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7.pkg4.pkg15.repaso;

import java.util.*;

public class Ejercicio7415Repaso {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int mesas[][] = new int[2][10];
        int aux;
        for (int i = 0; i < 10; i++) {
            mesas[0][i] = (int) (Math.random() * 4);
            mesas[1][i] = i + 1;
        }

        while (true) {
            System.out.print("Mesa:  ");
            for (int i = 0; i < 10; i++) {
                System.out.print(mesas[1][i] + " ");
            }
            System.out.print("\nHueco: ");
            for (int i = 0; i < 10; i++) {
                System.out.print(mesas[0][i] + " ");
            }

            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (mesas[0][i] < mesas[0][j]) {
                        aux = mesas[0][i];
                        mesas[0][i] = mesas[0][j];
                        mesas[0][j] = aux;
                        aux = mesas[1][i];
                        mesas[1][i] = mesas[1][j];
                        mesas[1][j] = aux;
                    }
                }
            }

            System.out.print("\n¿Cuantos sois?: ");
            int grupo = sc.nextInt();
            if (grupo < 0) {
                break;
            }

            for (int i = 0; i < 10; i++) {
                if ((mesas[0][i] + grupo) <= 4) {
                    if (mesas[0][i] == 0) {
                        mesas[0][i] += grupo;
                        System.out.println("Ireis a la mesa " + mesas[1][i] + " ya que esta vacia");
                        break;
                    } else {
                        mesas[0][i] += grupo;
                        System.out.println("Os pondre en la mesa " + mesas[1][i] + ", aunque compartiran con " + (mesas[0][i] - grupo) + " personas");
                        break;
                    }
                } else {
                    System.out.println("No hay hueco");
                    break;
                }
            }
            System.out.println("");
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (mesas[1][i] < mesas[1][j]) {
                        aux = mesas[0][i];
                        mesas[0][i] = mesas[0][j];
                        mesas[0][j] = aux;
                        aux = mesas[1][i];
                        mesas[1][i] = mesas[1][j];
                        mesas[1][j] = aux;
                    }
                }
            }

        }
    }
}
