/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7.pkg4.pkg1.repaso;

/**
 *
 * @author MM ISLAZUL
 */
public class Ejercicio741Repaso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num [] = new int[12];
        
        num [0] = 39;
        num [1] = -2;
        num [4] = 0;
        num [6] = 14;
        num [8] = 5;
        num [9] = 120;
        
        for (int i = 0;i < 12;i++){
            System.out.println(num[i]);               
        }
    }
    
}
